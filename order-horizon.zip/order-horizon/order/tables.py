import logging
from django.conf import settings
from django import urls
from django import template
from django.utils.translation import npgettext_lazy
from django.utils.translation import string_concat
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ungettext_lazy
from django.utils.http import urlencode
from django.http import HttpResponse
from horizon import tables
from openstack_dashboard import api
from openstack_dashboard.api import order
from openstack_dashboard import policy
from openstack_dashboard.dashboards.project.order.workflows \
    import update_instance
from openstack_dashboard.dashboards.project.floating_ips import workflows
LOG = logging.getLogger(__name__)
ACTIVE_STATES = ("ACTIVE",)
POWER_STATES = {
    0: "NO STATE",
    1: "RUNNING",
    2: "BLOCKED",
    3: "PAUSED",
    4: "SHUTDOWN",
    5: "SHUTOFF",
    6: "CRASHED",
    7: "SUSPENDED",
    8: "FAILED",
    9: "BUILDING",
}
def is_deleting(instance):
    task_state = getattr(instance, "OS-EXT-STS:task_state", None)
    if not task_state:
        return False
    return task_state.lower() == "deleting"
def get_power_state(instance):
    return POWER_STATES.get(getattr(instance, "OS-EXT-STS:power_state", 0), '')

def get_inetwork(order):
    template_name = 'project/order/_order_network.html'
    context = {
        "networks": order.internal_network_name,
    }
    return template.loader.render_to_string(template_name, context)

def get_enetwork(order):
    template_name = 'project/order/_order_network.html'
    context = {
        "networks": order.extenal_network_name,
    }
    return template.loader.render_to_string(template_name, context)
class MyFilterAction(tables.FilterAction):
    name = "myfilter"
class LaunchLink(tables.LinkAction):
    name = "launch"
    verbose_name = _("Launch Order")
    url = "horizon:project:order:launch"
    classes = ("ajax-modal", "btn-launch")
    icon = "cloud-upload"
    policy_rules = (("compute", "os_compute_api:servers:create"),)
    ajax = True
    def __init__(self, attrs=None, **kwargs):
        kwargs['preempt'] = True
        super(LaunchLink, self).__init__(attrs, **kwargs)
    def allowed(self, request, datum):
        return True
    def single(self, table, request, object_id=None):
        self.allowed(request, None)
        return HttpResponse(self.render(is_table_action=True))
class LaunchLinkNG(LaunchLink):
    name = "launch-ng"
    url = "horizon:project:order:index"
    ajax = False
    classes = ("btn-launch", )

    def get_default_attrs(self):
        url = urls.reverse(self.url)
        ngclick = "modal.openLaunchInstanceWizard(" \
            "{ successUrl: '%s' })" % url
        self.attrs.update({
            'ng-controller': 'LaunchInstanceModalController as modal',
            'ng-click': ngclick
        })
        return super(LaunchLinkNG, self).get_default_attrs()

    def get_link_url(self, datum=None):
        return "javascript:void(0);"
class DeleteOrder(policy.PolicyTargetMixin, tables.DeleteAction):
    policy_rules = (("compute", "os_compute_api:servers:delete"),)
    help_text = _("Deleted instances are not recoverable.")
    @staticmethod
    def action_present(count):
        return ungettext_lazy(
            u"Delete Order",
            u"Delete Orders",
            count
        )
    @staticmethod
    def action_past(count):
        return ungettext_lazy(
            u"Scheduled deletion of Instance",
            u"Scheduled deletion of Instances",
            count
        )
    def allowed(self, request, instance=None):
        error_state = False
        if instance:
            error_state = (instance.status == 'ERROR')
        return error_state or not is_deleting(instance)

    def action(self, request, obj_id):
        try:
            api.order.order_delete(request, obj_id)
        except Exception as e:
            pass
class StartInstance(policy.PolicyTargetMixin, tables.BatchAction):
    name = "start"
    classes = ('btn-confirm',)
    policy_rules = (("compute", "os_compute_api:servers:start"),)

    @staticmethod
    def action_present(count):
        return ungettext_lazy(
            u"Start Instance",
            u"Start Instances",
            count
        )

    @staticmethod
    def action_past(count):
        return ungettext_lazy(
            u"Started Instance",
            u"Started Instances",
            count
        )

    def allowed(self, request, instance):
        return ((instance is None) or
                (instance.status in ("SHUTDOWN", "SHUTOFF", "CRASHED")))

    def action(self, request, obj_id):
        api.nova.server_start(request, obj_id)
class StopInstance(policy.PolicyTargetMixin, tables.BatchAction):
    name = "stop"
    policy_rules = (("compute", "os_compute_api:servers:stop"),)
    help_text = _("The instance(s) will be shut off.")
    action_type = "danger"

    @staticmethod
    def action_present(count):
        return npgettext_lazy(
            "Action to perform (the instance is currently running)",
            u"Shut Off Instance",
            u"Shut Off Instances",
            count
        )

    @staticmethod
    def action_past(count):
        return npgettext_lazy(
            "Past action (the instance is currently already Shut Off)",
            u"Shut Off Instance",
            u"Shut Off Instances",
            count
        )

    def allowed(self, request, instance):
        return (instance is None or
                (get_power_state(instance) in ("RUNNING", "SUSPENDED") and
                 not is_deleting(instance)))

    def action(self, request, obj_id):
        api.nova.server_stop(request, obj_id)
class RebootInstance(policy.PolicyTargetMixin, tables.BatchAction):
    name = "reboot"
    classes = ('btn-reboot',)
    policy_rules = (("compute", "os_compute_api:servers:reboot"),)
    help_text = _("Restarted instances will lose any data"
                  " not saved in persistent storage.")
    action_type = "danger"

    @staticmethod
    def action_present(count):
        return ungettext_lazy(
            u"Hard Reboot Instance",
            u"Hard Reboot Instances",
            count
        )

    @staticmethod
    def action_past(count):
        return ungettext_lazy(
            u"Hard Rebooted Instance",
            u"Hard Rebooted Instances",
            count
        )

    def allowed(self, request, instance=None):
        if instance is not None:
            return ((instance.status in ACTIVE_STATES or
                     instance.status == 'SHUTOFF') and
                    not is_deleting(instance))
        else:
            return True

    def action(self, request, obj_id):
        api.nova.server_reboot(request, obj_id, soft_reboot=False)
class EditInstance(policy.PolicyTargetMixin, tables.LinkAction):
    name = "edit"
    verbose_name = _("Edit Instance")
    url = "horizon:project:instances:update"
    classes = ("ajax-modal",)
    icon = "pencil"
    policy_rules = (("compute", "os_compute_api:servers:update"),)

    def get_link_url(self, project):
        return self._get_link_url(project, 'instance_info')

    def _get_link_url(self, project, step_slug):
        base_url = urls.reverse(self.url, args=[project.id])
        next_url = self.table.get_full_url()
        params = {"step": step_slug,
                  update_instance.UpdateInstance.redirect_param_name: next_url}
        param = urlencode(params)
        return "?".join([base_url, param])

    def allowed(self, request, instance):
        return not is_deleting(instance)
class RebuildInstance(policy.PolicyTargetMixin, tables.LinkAction):
    name = "rebuild"
    verbose_name = _("Rebuild Instance")
    classes = ("btn-rebuild", "ajax-modal")
    url = "horizon:project:instances:rebuild"
    policy_rules = (("compute", "os_compute_api:servers:rebuild"),)
    action_type = "danger"

    def allowed(self, request, instance):
        return ((instance.status in ACTIVE_STATES or
                 instance.status == 'created') and
                not is_deleting(instance))

    def get_link_url(self, datum):
        instance_id = self.table.get_object_id(datum)
        return urls.reverse(self.url, args=[instance_id])
class AssociateIP(policy.PolicyTargetMixin, tables.LinkAction):
    name = "associate"
    verbose_name = _("Associate Floating IP")
    url = "horizon:project:floating_ips:associate"
    classes = ("ajax-modal",)
    icon = "link"
    policy_rules = (("network", "update_floatingip"),)

    def allowed(self, request, instance):
        if not api.base.is_service_enabled(request, 'network'):
            return False
        if not api.neutron.floating_ip_supported(request):
            return False
        if api.neutron.floating_ip_simple_associate_supported(request):
            return False
        if instance.status == "ERROR":
            return False
        if instance.extenal_network_name:
            return False
        return not is_deleting(instance)

    def get_link_url(self, datum):
        base_url = urls.reverse(self.url)
        next_url = self.table.get_full_url()
        params = {
            "instance_id": self.table.get_object_id(datum),
            workflows.IPAssociationWorkflow.redirect_param_name: next_url}
        params = urlencode(params)
        return "?".join([base_url, params])
class DisassociateIP(tables.LinkAction):
    name = "disassociate"
    verbose_name = _("Disassociate Floating IP")
    url = "horizon:project:instances:disassociate"
    classes = ("btn-disassociate", 'ajax-modal')
    policy_rules = (("network", "update_floatingip"),)
    action_type = "danger"

    def allowed(self, request, instance):
        if not api.base.is_service_enabled(request, 'network'):
            return False
        if not api.neutron.floating_ip_supported(request):
            return False
        for addresses in instance.addresses.values():
            for address in addresses:
                if address.get('OS-EXT-IPS:type') == "floating":
                    return not is_deleting(instance)
        return False
def get_server_detail_link(obj,request):
    return "/auth/switch/%s/?next=/project/instances/"%obj.project_id
class OrderTable(tables.DataTable):
    name = tables.Column('name',
                         link=get_server_detail_link,
                         verbose_name=_("Name"))
    image_name = tables.Column('image_name',
                               verbose_name=_("Image Name"))
    internal_network = tables.Column(get_inetwork,
                               verbose_name=_("Intranet"))
    extenal_network = tables.Column(get_enetwork,
                               verbose_name=_("Floating network"))
    flavor_name = tables.Column('flavor_name',
                               verbose_name=_("Flavor"))
    create_count = tables.Column('count',
                           verbose_name=_("Create Count"))
    start_time = tables.Column('start_time',
                           verbose_name=_("Start Time"))
    stop_time = tables.Column('stop_time',
                           verbose_name=_("Stop Time"))
    status = tables.Column('status',
                           verbose_name=_("Status"))
    class Meta(object):
        name = "order"
        verbose_name = _("Order")

        launch_actions = ()
        # if getattr(settings, 'LAUNCH_INSTANCE_LEGACY_ENABLED', False):
        launch_actions = (LaunchLink,) + launch_actions
        # if getattr(settings, 'LAUNCH_INSTANCE_NG_ENABLED', True):
        #     launch_actions = (LaunchLinkNG,) + launch_actions
        table_actions = launch_actions+(DeleteOrder,)
        table_actions_menu = (StartInstance, StopInstance, RebootInstance)
        row_actions=(EditInstance,RebuildInstance,AssociateIP,DisassociateIP)