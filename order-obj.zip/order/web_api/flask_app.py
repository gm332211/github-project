from flask import jsonify
import datetime
from web_api.views import db_handle
from conf import openstack_setting as lease_conf
from flask import Flask
from flask import request
from api import Openstack
from api import connect
# this is order api interface
conn=connect.Conn()
op=Openstack.Openstack(conn)
app=Flask(__name__)
db= db_handle.DBStore()
#flavor cookie
flavor_dict=op.list_flavor()
@app.route('/orders',methods=['POST'])
def order_create():
    response_data={'status':'201'}
    data=request.json
    name = data.get('name',None)
    image_id = data.get('image_id',None)
    flavor_id = data.get('flavor_id',None)
    network = data.get('networks',None)
    start_time = data.get('start_time',None)
    stop_time = data.get('stop_time',None)
    count = data.get('count', 1)
    status=data.get('status','wait')
    startTime = datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
    stopTime = datetime.datetime.strptime(stop_time, '%Y-%m-%d %H:%M:%S')
    v_token = request.headers.get('X-Auth-Token', None)
    print(network)
    try:
        user_id=op.get_user_id(v_token)
        admin_user=op.find_user(lease_conf.USERNAME)
        project=op.create_project(name)
        op.add_role(user_id=user_id,project_id=project.id)
        op.add_role(user_id=admin_user.id, project_id=project.id)
        flavor=op.get_flavor(flavor_id)
        op.update_quota(project_id=project.id,ram=int(flavor.ram)*int(count),cores=int(flavor.vcpus)*int(count),count=int(count))
        db.order_create(name=name, image_id=image_id, flavor_id=flavor_id, internal_network=network,
                        start_time=startTime, stop_time=stopTime, count=count, status=status,project_id=project.id,user_id=user_id)
    except Exception as e:
        response_data['status']='401'
        print(e)
    return jsonify(response_data)
@app.route('/orders',methods=['GET'])
def order_list():
    orders_dict={}
    v_token=request.headers.get('X-Auth-Token',None)
    user_id=op.get_user_id(user_token=v_token)
    orders=db.order_list(user_id=user_id)
    if orders:
        for order in orders:
            orders_dict[order.id]={
                'id':order.id,
                'name':order.name,
                'image_id':order.image_id,
                'flavor_id': order.flavor_id,
                'extenal_network':[],
                'internal_network': [],
                'start_time': order.start_time.strftime("%Y-%m-%d %H:%S:%M"),
                'stop_time': order.stop_time.strftime("%Y-%m-%d %H:%S:%M"),
                'count': order.count,
                'status': order.status,
                'project_id':order.project_id
            }
            networks=order.network
            if networks:
                for network in networks:
                    orders_dict[order.id]['internal_network'].append(network.in_network)
                    orders_dict[order.id]['extenal_network'].append(network.ext_network)
    return jsonify(orders_dict)
@app.route('/orders/<order_id>',methods=['DELETE'])
def order_delete(order_id):
    v_token = request.headers.get('X-Auth-Token', None)
    user_id=op.get_user_id(v_token)
    try:
        order_obj=db.order_select(user_id,order_id)
        if order_obj.status=='dead' or order_obj.status=='wait':
            try:
                op.delete_project(order_obj.project_id)
            except:
                pass
            networks=order_obj.network
            db.delete_db(order_obj)
            if networks:
                for network_obj in networks:
                    db.delete_db(network_obj)
        elif order_obj.status=='created':
            order_obj.status='deleteing'
            db.session.commit()
    except Exception as e:
        print(e)
        return 'error'
    return 'ok'
@app.route('/orders/<order_id>',methods=['PUT'])
def order_update(order_id):
    pass
@app.route('/orders/hypervisor/<start_time>',methods=['GET'])
def order_hypervisor(start_time):
    start_time=datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M')
    print(type(start_time))
    flavor_id_list=db.resource_compute(start_time)
    sum_ram =0
    sum_vcpus=0
    sum_disk=0
    if flavor_id_list:
        for flavor_id in flavor_id_list:
            flavor=flavor_dict.get('flavor_id',None)
            if not flavor:
                flavor_obj=op.get_flavor(name_or_id=flavor_id)
                flavor_dict[flavor_obj.id]={
                    'ram':flavor_obj.ram,
                    'vcpus': flavor_obj.vcpus,
                    'disk': flavor_obj.disk,
                }
                flavor={
                    'ram':flavor_obj.ram,
                    'vcpus': flavor_obj.vcpus,
                    'disk': flavor_obj.disk,
                }
            sum_ram=sum_ram+int(flavor.get('ram',0))
            sum_vcpus = sum_vcpus + int(flavor.get('vcpus', 0))
            sum_disk=sum_disk+int(flavor.get('disk', 0))
    print(sum_ram,sum_vcpus,sum_disk)
    data=op.hypervisors_stats()
    print(data)
    return jsonify({'status':'ok'})


app.run('0.0.0.0',port=int(lease_conf.WEBPORT),debug=True,threaded=True)