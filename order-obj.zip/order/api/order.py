from api import Openstack
from api import connect
from api.views import order_db_handle
import threading,Queue,time
conn=connect.Conn()
start_q=Queue.Queue()
stop_q=Queue.Queue()
action_q=Queue.Queue()
def Producer_Create():
    db = order_db_handle.DBStore()
    while True:
        groups=db.start_timeout()
        if groups:
            for group in groups:
                group_dict ={
                    "server": {
                        "name": group.name,
                        "imageRef": group.image_id,
                        "flavorRef": group.flavor_id,
                        "networks": [],
                        'min_count': group.count,
                        'max_count': group.count,
                    },
                    'project_id':group.project_id,
                    'bind_network':[],
                }
                network_list=[]
                for network in group.network:
                    network_list.append({"uuid": network.in_network})
                    if network.ext_network:
                        group_dict['bind_network'].append({'in_network':network.in_network,'ext_network':network.ext_network})
                group_dict['server']['networks']=network_list
                start_q.put(group_dict)
        time.sleep(10)
def Consumer_Create():
    while True:
        db_dict=start_q.get()
        if db_dict:
            data={}
            data['server']=db_dict.get('server',None)
            op = Openstack.UserOpenstack(project_id=db_dict.get('project_id',None))
            op.get_token()
            res_data=op.create_server(data)
            if res_data:
                bind_network=db_dict.get('bind_network',None)
                if bind_network:
                    for network in bind_network:
                        ports_id=op.list_port_id(network_id=network.get('in_network',None))
                        for port_id in ports_id:
                            op.float_create(float_network_id=network.get('ext_network',None),band_port_id=port_id)
def Threading_Create(count=1):
    t_list=[]
    for i in range(int(count)):
        t=threading.Thread(target=Consumer_Create)
        t_list.append(t)
    for t in t_list:
        t.start()
    for t in t_list:
        t.join()

def Producer_Delete():
    db = order_db_handle.DBStore()
    while True:
        groups=db.stop_timeout()
        deleteing=db.deleteing()
        if groups:
            for group in groups:
                group_dict={
                    'project_id':group.project_id
                }
                stop_q.put(group_dict)
            db.recycle_db(groups)
        if deleteing:
            for group in deleteing:
                group_dict={
                    'project_id':group.project_id
                }
                stop_q.put(group_dict)
            db.recycle_db(deleteing)
        time.sleep(10)
def Consumer_Delete():
    while True:
        db_dict=stop_q.get()
        if db_dict:
            op = Openstack.UserOpenstack(project_id=db_dict.get('project_id',None))
            op.get_token()
            id_list=op.list_server_id()
            op.delete_server(id_list)
            op.delete_float_all()
def Threading_Delete(count=1):
    t_list=[]
    for i in range(int(count)):
        t=threading.Thread(target=Consumer_Delete)
        t_list.append(t)
    for t in t_list:
        t.start()
    for t in t_list:
        t.join()

# def Producer_Action():
#     db = db_views.DBstore()
#     while True:
#         groups=db.group_action()
#         if groups:
#             op.get_token()
#             for group in groups:
#                 if group.status=='rebuild':
#                     count=0
#                     success = getattr(group, 'success', None)
#                     if success:
#                         count=count+len(success)
#                         for instance in success:
#                             instance_dict = {
#                                 'status':'rebuild',
#                                 'instance_id':instance.instance_id,
#                                 "image_id": group.image_id,
#                             }
#                             action_q.put(instance_dict)
#                     failures=getattr(group,'failure',None)
#                     if failures:
#                         count=count+len(failures)
#                         for failure in failures:
#                             failure_dict = {
#                                 'id': group.id,
#                                 'image_id': group.image_id,
#                                 'flavor_id': group.flavor_id,
#                                 'network_id': group.network_id,
#                                 'instance_name': failure.instance_name,
#                             }
#                             start_q.put(failure_dict)
#                             db.delete_db(failure)
#                     if count < int(group.instance_count):
#                         for i in range(int(group.instance_count)-count):
#                             price_dict = {
#                                 'id': group.id,
#                                 'image_id': group.image_id,
#                                 'flavor_id': group.flavor_id,
#                                 'network_id': group.network_id,
#                                 'instance_name':'%s-p%d'%(group.group_name,i+1),
#                             }
#                             start_q.put(price_dict)
#                     group.status='success'
#                     db.session.commit()
#                 if group.status=='reboot':
#                     success = getattr(group, 'success', None)
#                     if success:
#                         for instance in success:
#                             instance_dict={
#                                 'status':'reboot',
#                                 'instance_id':instance.instance_id
#                             }
#                             action_q.put(instance_dict)
#                     group.status='success'
#                     db.session.commit()
#                 if group.status=='stop':
#                     success = getattr(group, 'success', None)
#                     if success:
#                         for instance in success:
#                             instance_dict={
#                                 'status':'stop',
#                                 'instance_id':instance.instance_id
#                             }
#                             action_q.put(instance_dict)
#                     group.status='has-stop'
#                 if group.status=='start':
#                     success = getattr(group, 'success', None)
#                     if success:
#                         for instance in success:
#                             instance_dict={
#                                 'status':'start',
#                                 'instance_id':instance.instance_id
#                             }
#                             action_q.put(instance_dict)
#                     group.status='success'
# def Consumer_Action():
#     while True:
#         db_dict=action_q.get()
#         status=db_dict.get('status',None)
#         if status=='rebuild':
#             op.server_rebuild(db_dict)
#         elif status=='reboot':
#             op.server_reboot(db_dict)
#         elif status=='stop':
#             op.server_stop(db_dict)
#         elif status=='start':
#             op.server_start(db_dict)
# def Threading_Action(count=10):
#     t_list=[]
#     for i in range(count):
#         t=threading.Thread(target=Consumer_Action)
#         t_list.append(t)
#     for t in t_list:
#         t.start()
#     for t in t_list:
#         t.join()
